import "es6-promise/dist/es6-promise.auto.js";
export * from "./index";
