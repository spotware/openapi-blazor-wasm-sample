/** @private */
export declare class TextMessageFormat {
    static RecordSeparatorCode: number;
    static RecordSeparator: string;
    static write(output: string): string;
    static parse(input: string): string[];
}
